const express=require("express");
const app=express();
const path=require("path");
const port=3000;
const { v4: uuidv4 } = require('uuid');
const methodOverride = require('method-override');

app.use(methodOverride('_method'));
app.set("view engine","ejs");
app.set("views",path.join(__dirname,"views"));
app.use(express.static(path.join(__dirname,"public")));
app.use(express.urlencoded({extended:true}));

app.listen(port,(req,res)=>{
    console.log(`Listening on port ${port}`);
})

//data
let tasks=[
    {id:uuidv4(),
        title:"Express"  ,
        duedate:"2025-06-04"   ,
        status: "complete"  
    },
    {id:uuidv4(),
        title:"Backtracking"  ,
        duedate:"2025-09-10"   ,
        status: "incomplete"  
    },
    {id:uuidv4(),
        title:"DSA"  ,
        duedate:"2025-04-05"   ,
        status: "incomplete"  
    }
]


app.get("/tasks",(req,res)=>{
    res.render("index.ejs",{tasks});
})
app.get("/tasks/add",(req,res)=>{
    res.render("add.ejs",{tasks});
})

app.get("/tasks/:id/edit",(req,res)=>{
 let {id}=req.params;
   let task= tasks.find((t)=>t.id===id);
   if(task){
    res.render("edit.ejs",{task});
   }else{
    res.send("error");
   }
})

app.patch("/tasks/:id",(req,res)=>{
 let {id}=req.params;
   let task= tasks.find((t)=>t.id===id);
   let newt=req.body.title;
      let newd=req.body.duedate;
         let news=req.body.status;
      if(task){
    task.title=newt;
  task.status=news;
  task.duedate=newd;
     res.redirect("/tasks")
   }else{
    res.send("error");
   }     
})


app.post("/tasks/add",(req,res)=>{
    let{title,duedate,status}=req.body;
    tasks.push({title,duedate,status});
    res.redirect("/tasks");
})

app.get("/tasks/:id",(req,res)=>{
    let {id}=req.params;
   let task= tasks.find((t)=>t.id===id);
   if(task){
    res.render("show.ejs",{task});
   }else{
    res.send("error");
   }
})

app.post("/tasks",(req,res)=>{
    let id=uuidv4();
    let {title,duedate,status}=req.body;
    tasks.push({id,title,duedate,status});
    res.redirect("/tasks");
})

app.delete("/tasks/:id",(req,res)=>{
      let {id}=req.params;
   tasks=tasks.filter((o)=>o.id!==id);
   res.redirect("/tasks");
})